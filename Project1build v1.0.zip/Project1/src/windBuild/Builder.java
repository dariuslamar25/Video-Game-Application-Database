/*
 * Project Build 1.0
 *
 */
package windBuild;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.CallableStatement;
import java.sql.Types;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.BorderLayout;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.lang.System.Logger.Level;

import com.jgoodies.forms.factories.DefaultComponentFactory;

import net.proteanit.sql.DbUtils;

import javax.swing.JScrollBar;
import javax.swing.border.LineBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.JRadioButton;
import javax.swing.JList;
import javax.swing.JEditorPane;

public class Builder {

	static final String databasePrefix ="cs366-2231_syversonbl27"; // washington server link 
    static final String netID ="syversonbl27"; //  // lab reference
    static final String hostName ="washington.uww.edu";
    static final String databaseURL ="jdbc:mariadb://"+hostName+"/"+databasePrefix;
    static final String password="bs2719"; 
    private Connection connection = null;
	private Statement statement = null;
	private ResultSet resultSet = null;
	
	
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Builder window = new Builder();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Builder() {
		initialize();
		
		
	}
	

	ResultSet rs; // set type result set
	Connection con; // set type connection
	PreparedStatement pstate; // set type SQL statement
	
	
//	 public void simpleQuery(String sqlQuery) { // lab reference
//		    
//	    	try {
//	    		statement = connection.createStatement();
//	    		resultSet = statement.executeQuery(sqlQuery);
//
//	    		ResultSetMetaData metaData = resultSet.getMetaData();
//	    		int columns = metaData.getColumnCount();
//
//	    		for (int i=1; i<= columns; i++) {
//	    			System.out.print(metaData.getColumnName(i)+"\t");
//	    		}
//
//	    		System.out.println();
//
//	    		while (resultSet.next()) {
//	       
//	    			for (int i=1; i<= columns; i++) {
//	    				System.out.print(resultSet.getObject(i)+"\t\t");
//	    			}
//	    			System.out.println();
//	    		}
//	    	}
//	    	catch (SQLException e) {
//	    		e.printStackTrace();
//	    	}
//	    } // end of simpleQuery method
		
	
	public void Connection(){ // connection method designed to check SQL statement on button command top left hand button top 100 games

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		    System.out.println("databaseURL"+ databaseURL); // database call
			Connection connect = DriverManager.getConnection(databaseURL, netID, password);
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("select g.rank, g.name from Game g where rank <= 100"); // SQL statement
			
			while(table.getRowCount() > 0) {
				((DefaultTableModel)table.getModel()).removeRow(0); // checking table model count for row expansin with while loop
			}
			int col = rs.getMetaData().getColumnCount();
			while(rs.next()) {
				Object [] rows = new Object [col];
				for(int i = 1; i <= col; i++) {
					rows[i-1] = rs.getObject(i); // insert column based off new object being added(entity set) type
				}
				((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
			}
			rs.close();
			st.close();
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
			
		}
	} // end of Connection
	
	public void Connection2(){ // button List of Games

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		    System.out.println("databaseURL"+ databaseURL);
			Connection connect = DriverManager.getConnection(databaseURL, netID, password);
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("select g.name, g.platform, Sales.globalShipped, Score.criticScore from Game g, Sales, Score Where g.genre = Genre AND g.rank = Sales.salesRank AND g.rank = Score.scoreRank");
			
			while(table.getRowCount() > 0) {
				((DefaultTableModel)table.getModel()).removeRow(0);
			}
			int col = rs.getMetaData().getColumnCount();
			while(rs.next()) {
				Object [] rows = new Object [col];
				for(int i = 1; i <= col; i++) {
					rows[i-1] = rs.getObject(i);
				}
				((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
			}
			rs.close();
			st.close();
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	} // end of Connection
	
	public void Connection3(){ // button Critics

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		    System.out.println("databaseURL"+ databaseURL);
			Connection connect = DriverManager.getConnection(databaseURL, netID, password);
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("Select g.platform, SUM(s.globalShipped) As total_sales\r\n"
					+ "From Game g, Sales s\r\n"
					+ "Where g.rank=s.salesRank\r\n"
					+ "Group By g.platform\r\n"
					+ "Having total_sales>0\r\n"
					+ "");
			
			while(table.getRowCount() > 0) {
				((DefaultTableModel)table.getModel()).removeRow(0);
			}
			int col = rs.getMetaData().getColumnCount();
			while(rs.next()) {
				Object [] rows = new Object [col];
				for(int i = 1; i <= col; i++) {
					rows[i-1] = rs.getObject(i);
				}
				((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
			}
			rs.close();
			st.close();
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	} // end of Connection
	public void Connection4(){ // button Total Sales

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		    System.out.println("databaseURL"+ databaseURL);
			Connection connect = DriverManager.getConnection(databaseURL, netID, password);
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("select g.name, sc.criticScore from Game g, Score sc where g.rank = sc.scoreRank ORDER BY sc.criticScore DESC limit 10");
			
			while(table.getRowCount() > 0) {
				((DefaultTableModel)table.getModel()).removeRow(0);
			}
			int col = rs.getMetaData().getColumnCount();
			while(rs.next()) {
				Object [] rows = new Object [col];
				for(int i = 1; i <= col; i++) {
					rows[i-1] = rs.getObject(i);
				}
				((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
			}
			rs.close();
			st.close();
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	} // end of Connection
	
	public void Connection5(){ // Button Rank

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		    System.out.println("databaseURL"+ databaseURL);
			Connection connect = DriverManager.getConnection(databaseURL, netID, password);
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("Select g.name,g.platform, s.globalShipped,sc.criticScore, sc.userScore,sc.esrbRating, g.developer\r\n"
					+ "From Game g, Sales s, Score sc\r\n"
					+ "Where g.rank=s.salesRank And sc.scoreRank=g.rank limit 100;\r\n"
					+ "");
			
			while(table.getRowCount() > 0) {
				((DefaultTableModel)table.getModel()).removeRow(0);
			}
			int col = rs.getMetaData().getColumnCount();
			while(rs.next()) {
				Object [] rows = new Object [col];
				for(int i = 1; i <= col; i++) {
					rows[i-1] = rs.getObject(i);
				}
				((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
			}
			rs.close();
			st.close();
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	} // end of Connection
	
	public void Connection6(){ // Button Sales range

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		    System.out.println("databaseURL"+ databaseURL);
			Connection connect = DriverManager.getConnection(databaseURL, netID, password);
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("Select * \r\n"
					+ "From Sales \r\n"
					+ "Where globalShipped Between 10 And 35\r\n"
					+ "Order By globalShipped ASC\r\n"
					+ "");
			
			while(table.getRowCount() > 0) {
				((DefaultTableModel)table.getModel()).removeRow(0);
			}
			int col = rs.getMetaData().getColumnCount();
			while(rs.next()) {
				Object [] rows = new Object [col];
				for(int i = 1; i <= col; i++) {
					rows[i-1] = rs.getObject(i);
				}
				((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
			}
			rs.close();
			st.close();
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	} // end of Connection
	
	public void Connection7(){ // radio Button top-selling games of 2018

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		    System.out.println("databaseURL"+ databaseURL);
			Connection connect = DriverManager.getConnection(databaseURL, netID, password);
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("Select g.name,MAX(Sales.globalShipped)\r\n"
					+ "From Game g, Sales \r\n"
					+ "Where g.rank =Sales.salesRank And g.year= 2018\r\n"
					+ "");
			
			while(table.getRowCount() > 0) {
				((DefaultTableModel)table.getModel()).removeRow(0);
			}
			int col = rs.getMetaData().getColumnCount();
			while(rs.next()) {
				Object [] rows = new Object [col];
				for(int i = 1; i <= col; i++) {
					rows[i-1] = rs.getObject(i);
				}
				((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
			}
			rs.close();
			st.close();
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	} // end of Connection
	
	public void Connection8(){ // radio Button Top developer highest rating

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		    System.out.println("databaseURL"+ databaseURL);
			Connection connect = DriverManager.getConnection(databaseURL, netID, password);
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("    SELECT g.developer, AVG(sc.criticScore) AS avg_critic_score, AVG(sc.userScore) AS avg_user_score\r\n"
					+ "    FROM Game g\r\n"
					+ "    JOIN Score sc ON g.rank = sc.scoreRank\r\n"
					+ "    GROUP BY g.developer\r\n"
					+ "    ORDER BY (AVG(sc.criticScore) + AVG(sc.userScore)) DESC\r\n"
					+ "    LIMIT 1\r\n"
					+ "");
			
			while(table.getRowCount() > 0) {
				((DefaultTableModel)table.getModel()).removeRow(0);
			}
			int col = rs.getMetaData().getColumnCount();
			while(rs.next()) {
				Object [] rows = new Object [col];
				for(int i = 1; i <= col; i++) {
					rows[i-1] = rs.getObject(i);
				}
				((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
			}
			rs.close();
			st.close();
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	} // end of Connection
	
	public void Connection9(){ // radio button top selling game on platform list

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		    System.out.println("databaseURL"+ databaseURL);
			Connection connect = DriverManager.getConnection(databaseURL, netID, password);
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("Select g.platform,g.name, Max(s.globalShipped) As max_sales From  Game g, Sales s\r\n"
					+ "Where g.rank = s.salesRank\r\n"
					+ "Group By g.platform\r\n"
					+ "Having max_sales>0\r\n"
					+ "");
			
			while(table.getRowCount() > 0) {
				((DefaultTableModel)table.getModel()).removeRow(0);
			}
			int col = rs.getMetaData().getColumnCount();
			while(rs.next()) {
				Object [] rows = new Object [col];
				for(int i = 1; i <= col; i++) {
					rows[i-1] = rs.getObject(i);
				}
				((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
			}
			rs.close();
			st.close();
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	} // end of Connection
	
	public void Connection10(){ // radio button top selling by ESRB

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		    System.out.println("databaseURL"+ databaseURL);
			Connection connect = DriverManager.getConnection(databaseURL, netID, password);
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("Select g.name, s.globalShipped, sc.esrbRating\r\n"
					+ "From Game g, Sales s, Score sc\r\n"
					+ "Where g.rank = s.salesRank and sc.scoreRank = g.rank\r\n"
					+ "Order By sc.esrbRating DESC\r\n"
					+ "Limit 10\r\n"
					+ "");
			
			while(table.getRowCount() > 0) {
				((DefaultTableModel)table.getModel()).removeRow(0);
			}
			int col = rs.getMetaData().getColumnCount();
			while(rs.next()) {
				Object [] rows = new Object [col];
				for(int i = 1; i <= col; i++) {
					rows[i-1] = rs.getObject(i);
				}
				((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
			}
			rs.close();
			st.close();
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	} // end of Connection
	
	
	private JTable table;
	private JTextField tName;
	private JTextField tGenre;
	private JTextField tPlatform;
	private JTextField tDeveloper;
	private JTextField tRank;
	private JTextField tYear;
	
	void setColor(JButton btnNewButton) {
		btnNewButton.setBackground(new Color(135, 112, 225));
	}
	void resetColor(JPanel panel) {
		panel.setBackground(new Color(76, 41, 211));
	}
		
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setForeground(new Color(204, 204, 204));
		frame.setBackground(new Color(240, 255, 255));
		frame.getContentPane().setForeground(new Color(204, 204, 204));
		frame.setBounds(100, 100, 1136, 662);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Game Search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(10, 10, 452, 600);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("Top 100 Games");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Connection(); // method call button
				
			}
		});
		btnNewButton.setBounds(24, 22, 129, 35);
		panel.add(btnNewButton);
		
		JButton btnListOfGames = new JButton("List of Games");
		btnListOfGames.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Connection2(); // method call button
			}
		});
		btnListOfGames.setBounds(24, 59, 129, 35);
		panel.add(btnListOfGames);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(14, 127, 100, 35);
		panel.add(lblNewLabel);
		
		JLabel lblGenre = new JLabel("Genre");
		lblGenre.setBounds(14, 166, 54, 35);
		panel.add(lblGenre);
		
		JLabel lblPlatform = new JLabel("Platform");
		lblPlatform.setBounds(14, 203, 110, 35);
		panel.add(lblPlatform);
		
		JLabel lblDeveloper = new JLabel("Developer");
		lblDeveloper.setBounds(10, 240, 104, 28);
		panel.add(lblDeveloper);
		
		tName = new JTextField();
		tName.setBounds(70, 135, 118, 19);
		panel.add(tName);
		tName.setColumns(10);
		
		tGenre = new JTextField();
		tGenre.setColumns(10);
		tGenre.setBounds(70, 174, 118, 19);
		panel.add(tGenre);
		
		tPlatform = new JTextField();
		tPlatform.setColumns(10);
		tPlatform.setBounds(70, 211, 118, 19);
		panel.add(tPlatform);
		
		tDeveloper = new JTextField();
		tDeveloper.setColumns(10);
		tDeveloper.setBounds(70, 248, 118, 19);
		panel.add(tDeveloper);
		
		JButton btnNewButton_1_1 = new JButton("Find");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String rank = tRank.getText(); // get text from Game set primary key 'rank'
					
					Class.forName("org.mariadb.jdbc.Driver");
				    System.out.println("databaseURL"+ databaseURL); // establish connection 
					Connection connect = DriverManager.getConnection(databaseURL, netID, password);
					Statement st = connect.createStatement();
					ResultSet rs = st.executeQuery("select g.name, g.genre, g.platform, g.developer, g.year from Game g where g.rank= '"+rank+"';"); // SQl statement
					//int rank = Integer.parseInt(tRank.getText());
					//pstate.setInt(1, rank);
					if(rs.next() == false) {
					tName.setText(""); // setText point to check if statement has given request from rank key
					tGenre.setText("");
					tPlatform.setText("");
					tDeveloper.setText("");
					tYear.setText("");
			
					tRank.requestFocus();
				}
				else {
					tName.setText(rs.getString("Name")); // then print out based on string result from table 
					tGenre.setText(rs.getString("Genre"));
					tPlatform.setText(rs.getString("Platform"));
					tDeveloper.setText(rs.getString("Developer"));
					tYear.setText(rs.getString("Year"));
					
					while(table.getRowCount() > 0) { // not needed for statement to work 
						((DefaultTableModel)table.getModel()).removeRow(0);
					}
					int col = rs.getMetaData().getColumnCount();
					while(rs.next()) {
						Object [] rows = new Object [col]; 
						for(int i = 1; i <= col; i++) {
							rows[i-1] = rs.getObject(i);
						}
						((DefaultTableModel)table.getModel()).insertRow(rs.getRow() -1, rows);
					}
					rs.close();
					st.close();
				
				}
				}
				catch (ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				catch (SQLException ex) {
					ex.printStackTrace();
				}
			} // end of Connection
			
			
				
		});
		btnNewButton_1_1.setBounds(222, 437, 85, 21);
		panel.add(btnNewButton_1_1);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new TitledBorder(null, "Search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_3.setBounds(10, 380, 191, 78);
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblRank = new JLabel("Rank");
		lblRank.setBounds(10, 33, 41, 16);
		panel_3.add(lblRank);
		
		tRank = new JTextField();
		tRank.setBounds(61, 33, 96, 19);
		tRank.setColumns(10);
		panel_3.add(tRank);
		
		JButton btnNewButton_1 = new JButton("Total Sales");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection3(); // method call
			}
		});
		btnNewButton_1.setBounds(155, 59, 129, 35);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Critics");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection4();// method call
			}
		});
		btnNewButton_2.setBounds(155, 22, 129, 35);
		panel.add(btnNewButton_2);
		
		JLabel lblYear = new JLabel("Year");
		lblYear.setBounds(10, 273, 100, 28);
		panel.add(lblYear);
		
		tYear = new JTextField();
		tYear.setColumns(10);
		tYear.setBounds(70, 278, 118, 19);
		panel.add(tYear);
		
		JButton btnNewButton_2_1 = new JButton("Rank");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection5(); // method call
			}
		});
		btnNewButton_2_1.setBounds(283, 22, 129, 35);
		panel.add(btnNewButton_2_1);
		
		JButton btnNewButton_2_2 = new JButton("Sales Range");
		btnNewButton_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection6(); // method call
			}
		});
		btnNewButton_2_2.setBounds(283, 59, 129, 35);
		panel.add(btnNewButton_2_2);
		
		JRadioButton t2018 = new JRadioButton("Top-Selling game of 2018");
		t2018.setForeground(new Color(255, 255, 255));
		t2018.setBackground(new Color(0, 0, 255));
		t2018.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection7(); // method call
			}
		});
		t2018.setBounds(206, 134, 240, 21);
		panel.add(t2018);
		
		JRadioButton rdbtnTopdevelopeGlobalShipped = new JRadioButton("Top-Developer Highest Rating");
		rdbtnTopdevelopeGlobalShipped.setForeground(new Color(255, 255, 255));
		rdbtnTopdevelopeGlobalShipped.setBackground(new Color(0, 0, 255));
		rdbtnTopdevelopeGlobalShipped.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection8(); // method call
			}
		});
		rdbtnTopdevelopeGlobalShipped.setBounds(206, 179, 240, 21);
		panel.add(rdbtnTopdevelopeGlobalShipped);
		
		JRadioButton t2018_2 = new JRadioButton("Top-Selling Game on Platform");
		t2018_2.setBackground(new Color(0, 0, 255));
		t2018_2.setForeground(new Color(255, 255, 255));
		t2018_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection9(); // method call
			}
		});
		t2018_2.setBounds(206, 217, 240, 21);
		panel.add(t2018_2);
		
		JRadioButton t2018_3 = new JRadioButton("Top-Selling Game by ESRB");
		t2018_3.setBackground(new Color(0, 0, 255));
		t2018_3.setForeground(new Color(255, 255, 255));
		t2018_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection10(); // method call
			}
		});
		t2018_3.setBounds(206, 256, 240, 21);
		panel.add(t2018_3);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(472, 10, 607, 468);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Data Set", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_2.setBounds(-6, 0, 620, 599);
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 15, 600, 456);
		panel_2.add(scrollPane);
		
		table = new JTable(); // table build 
		
		table.setFillsViewportHeight(true);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		scrollPane.setViewportView(table);
		table.setForeground(new Color(255, 255, 255));
		table.setBackground(new Color(0, 0, 128));
		table.setRowHeight(30);
		table.setRowHeight(100, 100);
		
		
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, "", null, null, null, null, null, null},
			},
			new String[] {
				"1", "2", "3", "4", "5", "6", "7", "8" // set title column
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table.getColumnModel().getColumn(0).setPreferredWidth(200); // lengths 
		table.getColumnModel().getColumn(1).setMinWidth(10);
		table.getColumnModel().getColumn(2).setMinWidth(10);
		table.getColumnModel().getColumn(3).setMinWidth(10);
		table.getColumnModel().getColumn(4).setMinWidth(10);
		table.getColumnModel().getColumn(5).setMinWidth(10);
		
		JLabel label = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/52761-video-game-icon.png")).getImage();
		label.setIcon(new ImageIcon(img));
		label.setBounds(641, 478, 310, 132);
		frame.getContentPane().add(label);
		
		JButton btnNewButton_3 = new JButton("Exit");
		btnNewButton_3.setBounds(958, 530, 145, 80);
		frame.getContentPane().add(btnNewButton_3);
		btnNewButton_3.setBackground(new Color(255, 0, 0));
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnNewButton_3.setForeground(new Color(0, 0, 0));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0); // exit button 
			}
		});
		
		
		
	}
}
